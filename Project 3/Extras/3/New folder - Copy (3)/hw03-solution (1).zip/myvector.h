/*myvector.h*/

//
// myvector class --- a replacement for std::vector based on linked
// nodes of array "chunks".  The idea is to avoid the need to reallocate
// the underlying dynamic array (and copying elements) when the vector
// becomes full.
//
// Prof. Joe Hummel
// U. of Illinois, Chicago
// CS341, Fall 2016
// HW #03 -- Solution
//

#pragma once

#include <iostream>
#include <iterator>
#include <exception>
#include <stdexcept>

using namespace std;


//
// myvector<T>
//
template<typename T>
class myvector
{
private:
  //
  // One node of the vector, i.e. an array "chunk" of size nodeSize.
  //
  class Node
  {
  public:
    T           *elements;
    int          nodeSize;
    int          numElems;
    class Node  *next;

    Node(int nodesize)
      : elements{ new T[nodesize] }, nodeSize{ nodesize }, numElems{ 0 }, next{ nullptr }
    { }

    ~Node()
    {
      delete[] elements;
    }

    void push_back(const T& e)
    {
      if (numElems == nodeSize)
        throw std::exception("node is full!");

      elements[numElems] = e;
      numElems++;
    }
  };

  //
  // Keeps track of our position while iterating through the vector.
  //
  class iterator 
  {
  public:
    Node  *cur;
    int    index;

    // 
    // constructor: first element in this node:
    //
    iterator(Node *head)
      : cur{ head }, index { 0 }
    { }

    //
    // constructor: specified element in this node:
    //
    iterator(Node *head, int i)
      : cur{ head }, index{ i }
    { }

    //
    // advance iterator to the next element --- if we are
    // at the end of the node, advance to the next node
    // in the linked-list:
    //
    iterator& operator++()
    {
      index++;

      if (index == cur->nodeSize)
      {
        cur = cur->next;
        index = 0;
      }

      return *this;
    }

    //
    // return element denoted by iterator:
    //
    T& operator*()
    {
      return cur->elements[index];
    }


    //
    // is *this* iterator != to given iterator?
    //
    bool operator!=(const iterator& rhs)
    {
      //
      // != if denote different nodes, or different indices:
      //
      if (cur != rhs.cur)
        return true;
      if (index != rhs.index)
        return true;

      return false;
    }
  };

  //
  // myvector:
  //
private:
  Node  *head;
  Node  *tail;
  int    nodeSize;
  int    numNodes;
  int    numElems;

public:
  //
  // constructor with given node size --- default to 100
  //
  myvector(int nodesize = 100)
    : head{ new Node(nodesize) }, tail{ head }, nodeSize{ nodesize }, numNodes{ 1 }, numElems{ 0 }
  { }

  //
  // copy constructor:
  //
  myvector(const myvector& other)
    : head { new Node(other.nodeSize) }, tail{ head }, nodeSize{ other.nodeSize }, numNodes{ other.numNodes }, numElems{ other.numElems }
  {
    //
    // We have to copy each node, and the contents of each node.
    // The first N-1 nodes are full, so let's copy those first...
    //
    Node *mycur = head;
    Node *othercur = other.head;

    for (int i = 0; i < numNodes - 1; ++i)
    {
      // copy over elements from other's current node:
      for (int j = 0; j < nodeSize; ++j)
        mycur->push_back(othercur->elements[j]);

      mycur->next = new Node(nodeSize);
      mycur = mycur->next;
      othercur = othercur->next;
    }

    //
    // fill the last, "tail" node, which may not be full:
    //
    tail = mycur;

    for (int j = 0; j < other.tail->numElems; ++j)
      tail->push_back(other.tail->elements[j]);

    //
    // that's it, copy complete:
    //
  }

  //
  // destructor: destruct each node in LL
  //
  ~myvector()
  {
    Node *cur, *temp;

    cur = head;
    while (cur != nullptr)
    {
      temp = cur;
      cur = cur->next;
      delete temp;
    }
  }

  int size()
  {
    return numElems;
  }

  int capacity()
  {
    return numNodes * nodeSize;
  }

  //
  // push given element into last node --- if full, allocate
  // a new node and start there.
  //
  void push_back(const T& e)
  {
    if (numElems == capacity())  // full, we need another node:
    {
      Node *n = new Node(nodeSize);

      numNodes++;

      tail->next = n;
      tail = n;
    }

    tail->push_back(e);
    numElems++;
  }

  //
  // access ith element in the vector, which means
  // traverse down LL to node containing ith element,
  // and access:
  //
  T& operator[](int i)
  {
    if (i < 0 || i >= numElems)
      throw std::invalid_argument("i out of bounds");

    //
    // we have to walk down the nodes until i falls into that node...
    //
    int nodes = i / nodeSize;

    Node *cur = head;
    while (nodes > 0)
    {
      cur = cur->next;
      nodes--;
    }

    // 
    // we have the right node, now index into node to get ith element:
    //
    i = i % nodeSize;

    return cur->elements[i];
  }

  //
  // first element:
  //
  T& front()
  {
    if (numElems == 0)
      throw std::exception("vector is empty!");

    return head->elements[0];
  }

  //
  // last element:
  //
  T& back()
  {
    if (numElems == 0)
      throw std::exception("vector is empty!");

    return tail->elements[tail->numElems - 1];
  }

  //
  // return iterator to first element:
  //
  iterator begin()
  {
    return iterator(head);
  }

  //
  // return iterator to first element that does *not*
  // exist:
  //
  iterator end()
  {
    //
    // we need to "point" to the first element that
    // doesn't exist...  However, what if that node 
    // is full?  Then end() is really the next element
    // from the perspective of ++ --- so we need to
    // advance (yes, to a node that doesn't exist):
    //
    if (tail->numElems < tail->nodeSize)
      return iterator(tail, tail->numElems);
    else // advance and return that iterator
    {
      Node *cur = tail->next;
      int   index = 0;

      return iterator(cur, index);
    }
  }

};
